import React, { useState } from "react";
// import logo from "./logo.svg";
// import "./App.css";
// import axios from "axios";
// import { upload } from "@testing-library/user-event/dist/upload";

// const API_BASE = "http://192.168.1.8:3000";

// function submitForm(contentType, data, setResponse) {
//   axios({
//     url: `${API_BASE}/upload`,
//     method: "POST",
//     data: data,
//     headers: {
//       "Content-Type": contentType,
//     },
//   })
//     .then((response) => {
//       setResponse(response.data);
//     })
//     .catch((error) => {
//       setResponse("error");
//     });
// }

// function App() {
//   const [title, setTitle] = useState("");
//   const [file, setFile] = useState(null);
//   const [desc, setDesc] = useState("");

//   async function upload() {
//     const read = (file) =>
//       new Promise((resolve, reject) => {
//         const reader = new FileReader();
//         reader.readAsDataURL(file);
//         reader.onload = () => resolve(reader.result);
//         reader.onerror = (error) => reject(error);
//       });

//     const data = {
//       // title: title,
//       file: await read(file),
//       // desc: desc,
//     };

//     submitForm("application/json", data, (msg) => console.log(msg));
//   }

//   return (
//     <div className="App">
//       <h2>Upload Form</h2>
//       <form>
//         <label>
//           File Title
//           <input
//             type="text"
//             vaue={title}
//             onChange={(e) => {
//               setTitle(e.target.value);
//             }}
//             placeholder="Give a title to your upload"
//           />
//         </label>

//         <label>
//           File
//           <input
//             type="file"
//             name="file"
//             onChange={(e) => {
//               console.log(e.target.files[0]);
//               setFile(e.target.files[0]);
//             }}
//           />
//         </label>

//         <label>
//           Description
//           <textarea
//             value={desc}
//             onChange={(e) => setDesc(e.target.value)}
//           ></textarea>
//         </label>

//         <button type="button" value="Upload" onClick={upload}>
//           Upload
//         </button>
//       </form>
//     </div>
//   );
// }
// export default App;

import axios from "axios";

function App() {
  const [file, setFile] = useState();
  const [fileName, setFileName] = useState("");

  const saveFile = (e) => {
    setFile(e.target.files[0]);
    setFileName(e.target.files[0].name);
  };

  const uploadFile = async (e) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("fileName", fileName);
    try {
      const res = await axios.post(
        "http://localhost:5000/api/v1/users/profilepic",
        formData
      );
      console.log(res);
    } catch (ex) {
      console.log(ex);
    }
  };

  return (
    <div className="App">
      <input type="file" onChange={saveFile} />
      <button onClick={uploadFile}>Upload</button>
    </div>
  );
}

export default App;
